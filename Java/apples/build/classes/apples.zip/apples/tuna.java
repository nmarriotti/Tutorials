/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package apples;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;

public class tuna extends JFrame {
    
    private JLabel item1;
    private JButton item2;
    
    public tuna() {
        super("The title bar");
        setLayout(new FlowLayout());
        
        item1 = new JLabel("This is a sentence");
        item1.setToolTipText("This is a tooltip");
        add(item1);
        
        item2 = new JButton("Button");
        add(item2);
    }
    
}
