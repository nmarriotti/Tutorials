package apples;
import java.awt.BorderLayout;
import java.awt.GraphicsDevice;
import java.awt.Toolkit;
import java.awt.Window;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Toolbar extends JFrame {
    
    /* Define variables */
    JToolBar tb, tbSouth;
    JButton exit, loadCSV, fullScreen, open;
    ImageIcon exitIcon, submitIcon, iconFullScreen, iconFileChooser;
    JTextField filename;
    JTextArea textArea;
    JLabel status;
    boolean isMaximized;
    JFileChooser browseFiles;
    String missionName, area, FMC, msnDate = null;
    List<Mission> missionList = new ArrayList<Mission>();
    int errorsFound = 0;
    
    public Toolbar() {
        
        isMaximized = false;
        
        setSize(400,400);
        setTitle("Parse CSV");
        
        /* Create a toolbar object */
        tb = new JToolBar();
        tbSouth = new JToolBar();
        
        /* Create a button with an image and tooltip */
        exitIcon = new ImageIcon("images/exit.png");
        exit = new JButton(exitIcon);
        exit.setToolTipText("Exit");
        exit.setBorderPainted(false);
        
        /* Create fullscreen button */
        iconFullScreen = new ImageIcon("images/fullscreen.png");
        fullScreen = new JButton(iconFullScreen);
        fullScreen.setToolTipText("Fullscreen");
        fullScreen.setBorderPainted(false);
        
        /* Add the buttons to the toolbar */
        tb.add(exit);
        tb.add(fullScreen);
        
        /* Lock the toolbar in place at the top of the window */
        tb.setFloatable(false);
        add(tb, BorderLayout.NORTH);
        
        /* Add toolbar at the bottom of window */
        tbSouth.setFloatable(false);
        add(tbSouth, BorderLayout.SOUTH);
        
        /*Add Label to bottom toolbar */
        status = new JLabel();
        tbSouth.add(status);
        
        /* Create a textbox */
        filename = new JTextField(10);
        filename.setEditable(false);
        tb.add(filename);
        
        /* Create a file chooser */
        iconFileChooser = new ImageIcon("images/open.png");
        open = new JButton(iconFileChooser);
        open.setToolTipText("Exit");
        open.setBorderPainted(false);
        tb.add(open);
        
        /* Create load csv button and add to toolbar */
        submitIcon = new ImageIcon("images/submit.png");
        loadCSV = new JButton(submitIcon);
        loadCSV.setToolTipText("Load and parse CSV from filename");
        loadCSV.setBorderPainted(false);
        loadCSV.setEnabled(false);
        tb.add(loadCSV);
        
        /* Add textarea */
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        textArea.setEditable(true);
        textArea.setText("Load a CSV file and click the green button to process...");
        add(textArea);

        /* Add an event handler to the buttons */
        Handler theHandler = new Handler();
        exit.addActionListener(theHandler);
        loadCSV.addActionListener(theHandler);
        fullScreen.addActionListener(theHandler);
        open.addActionListener(theHandler);
    }
    
    private class Handler implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            String string = null;
            
            // Check if the user clicked the browse button
            if(event.getSource() == open) {
               browseFiles();
            }
            
            /* Check if the exit button was clicked*/
            else if(event.getSource() == exit) {
                showExitDialog();  
                
            } else if(event.getSource() == loadCSV) {
                
                // Process the CSV
                parseCSV(filename.getText());
                
            }  else if(event.getSource() == fullScreen) {
                maximizeWindow();
            } 
        }
    }
    
    boolean checkFileExists(String fpath) {
        File f = new File(fpath);
        if(f.exists() && !f.isDirectory()) {
            return true;
        } else {
            return false;
        }
    }
    
    void maximizeWindow() {
        if(isMaximized) {
            setExtendedState(JFrame.NORMAL);
            isMaximized = false;
        }
        else {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            isMaximized = true;
        }
    }
    
    void browseFiles() {
        browseFiles = new JFileChooser();
        FileNameExtensionFilter txtType = new FileNameExtensionFilter("Comma Delimited (.csv)", "csv");
        browseFiles.addChoosableFileFilter(txtType);
        int result = browseFiles.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            // user selects a file
            File selectedFile = browseFiles.getSelectedFile();
            // Load filename into textbox
            filename.setText(selectedFile.getAbsolutePath());
            if(checkFileExists(selectedFile.getAbsolutePath())) {
                loadCSV.setEnabled(true);
                status.setText("Ready to parse!");
            } else {
                // File does not exist
                filename.setText(null);
                loadCSV.setEnabled(false);
            }
        }
    }
    
    public void showExitDialog() {
        //Ask if the user wants to exit the program
        Object[] options = {"Yes",
                            "No"};
        int n = JOptionPane.showOptionDialog(this,"Are you sure you want to exit?", "Are you sure?",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        options,
        options[1]);
        
        // Check if YES was clicked and close the app
        if (n == JOptionPane.YES_OPTION) {
            setVisible(false);
        }
    }
    
    public void parseCSV(String fpath) {
        
        int lineNumber = 0;
        
        //Count the number of lines in the file
        try {
            FileReader fr = new FileReader(fpath);
            LineNumberReader lnr = new LineNumberReader(fr);
               
            //Count each line until it reaches a blank line
            while(lnr.readLine() != null) {
                lineNumber++;
            }
        
        } catch(IOException e){
            e.printStackTrace();
    	}
        
        System.out.println("Lines: " + lineNumber);
        
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(fpath))) {
            
            //Set current line to 1
            int currentLine = 1;
            
            while ((line = br.readLine()) != null) {
                //Remove quotes from line
                line = line.replace("\"", "");
                
                //Split into array where there is a comma
                String[] info = line.split(cvsSplitBy);
                
                //load the mission details into an array and set variables
                if (currentLine == 1) {
                    //textArea.setText(Arrays.toString(info) + "\n");
                    missionName = info[0];
                    area = info[2];
                    msnDate = info[1];
                    FMC = info[3];
                    System.out.println(missionName + " " + msnDate + " " + area + " " + FMC);
                    
                    // Create a new mission and load values
                    Mission mission = new Mission();
                    mission.setName(missionName);
                    mission.setDate(msnDate);
                    mission.setArea(area);
                    mission.setFMC(FMC);
                    
                    // Create ArrayList and add mission
                    missionList.add(mission);
                    
                    // Check if values are set
                    System.out.println(mission.getName());
                }
                else if(currentLine >= 3) {
                    //textArea.append(Arrays.toString(info) + "\n");
                    
                    // Process the first signal
                    Signal signal = new Signal();
                    signal.setFilename(info[0]);
                    signal.Parse();
                    
                    outputResults();
                }
                //increment the current line
                missionList.get(0).setSignalCount();
                currentLine++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        
        status.setText("Processed " + lineNumber + " line(s) successfully!");
    }
    
    public void outputResults() {
        textArea.setText("Mission: " + missionList.get(0).getName() + "\n");
        textArea.append("Total Files: " + missionList.get(0).getSignalCount() + "\n");
        textArea.append("========= \n");
        textArea.append("Mission processed successfully!");
        
    }
}
