/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apples;
import javax.swing.JFrame;

public class Apples {

    public static void main(String[] args) {
        EventHandler window2 = new EventHandler();
        window2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window2.setSize(500,500);
        window2.setVisible(true);
    }
    
}
