class Kml():
	def __init__(self):
		self.points = []
	
	def getLineString(self, coordinates):
		print "Writing LineString for {}".format(coordinates)
		linestring = '''    <Placemark id="track1">
        <name>path</name>
        <LineString>
            <coordinates>COORDINATES</coordinates>
        </LineString>
    </Placemark>'''
    
		list_coords = ','.join(map(str, coordinates))
		linestring = linestring.replace("COORDINATES",list_coords)
		return linestring

	
	def getPoint(self, name, coordinates):
		print "Writing point... for {}".format(coordinates)
		point = '''  <Placemark>
    <name>NAME</name>
    <Point>
      <coordinates>COORDINATES</coordinates>
    </Point>
  </Placemark>'''
  		point = point.replace("NAME",str(name)).replace("COORDINATES",coordinates)
  		return point
	
	
	def save(self, filename):
		headers = '''<?xml version='1.0' encoding='UTF-8'?>
<kml xmlns='http://earth.google.com/kml/2.1'>
<Document>'''
		with open(filename, "w") as kmlfile:
			kmlfile.write(headers)
			for item in self.points:
				kmlfile.write(item)
			kmlfile.write("</Document>\n</kml>")
